function [para, fBestSeqBest, modelBest, foldBest] = tuneNormal(data, tuneMode, algoMode, opt)
    disp(['            �� hyperparameter optimization of ' algoMode ' model with ' tuneMode '...']);
    
    %% calculate
    % initialize
    switch algoMode
        case 'SVM'
            if ~isfield(opt, 'SVM') || ~isfield(opt.SVM, 'init')
                init = [4, 4]';  % C,gamma
            else
                init = opt.SVM.init;
            end
        case 'LR'
            if ~isfield(opt, 'LR') || ~isfield(opt.LR, 'init')
                init    = []';
            else
                init = opt.NB.init;
            end
        case 'MLR'
            if ~isfield(opt, 'MLR') || ~isfield(opt.MLR, 'init')
                init    = []';
            else
                init = opt.NB.init;
            end
        case 'MLSSVR'
            if ~isfield(opt, 'MLSSVR') || ~isfield(opt.MLSSVR, 'init')
                init = [0.5;4;3];   % gamma, lambda, p
            else
                init = opt.MLSSVR.init;
            end
    end
    
    optTune = opt;
    optTune.data.dataName = data.dataName;
    optTune.data.posOutput = data.posOutput;
    if ~isfield(opt, 'data') || ~isfield(opt.data, 'crossCount')
        optTune.time = 10; 
    else
        optTune.time = opt.data.crossCount;
    end
    
    % optimize
    switch algoMode
        case 'SVM'
            if ~isfield(opt, 'SVM') || ~isfield(opt.SVM, 'BAS') || ~isfield(opt.SVM.BAS, 'eta'),    opt.SVM.BAS.eta     = 0.95; end
            if ~isfield(opt, 'SVM') || ~isfield(opt.SVM, 'BAS') || ~isfield(opt.SVM.BAS, 'c'),      opt.SVM.BAS.c       = 5;    end
            if ~isfield(opt, 'SVM') || ~isfield(opt.SVM, 'BAS') || ~isfield(opt.SVM.BAS, 'step'),   opt.SVM.BAS.step    = 4;    end
            if ~isfield(opt, 'SVM') || ~isfield(opt.SVM, 'BAS') || ~isfield(opt.SVM.BAS, 'n'),      opt.SVM.BAS.n       = 50;   end
            if ~isfield(opt, 'SVM') || ~isfield(opt.SVM, 'BAS') || ~isfield(opt.SVM.BAS, 'alpha'),  opt.SVM.BAS.alpha   = 0.2;  end
            if ~isfield(opt, 'SVM') || ~isfield(opt.SVM, 'BAS') || ~isfield(opt.SVM.BAS, 'isLevy'), opt.SVM.BAS.isLevy  = false;end
            optTune.BAS = opt.SVM.BAS;
        case 'LR'
            if ~isfield(opt, 'LR') || ~isfield(opt.LR, 'BAS') || ~isfield(opt.LR.BAS, 'eta'),   opt.LR.BAS.eta      = 0.95; end
            if ~isfield(opt, 'LR') || ~isfield(opt.LR, 'BAS') || ~isfield(opt.LR.BAS, 'c'),     opt.LR.BAS.c        = 5;    end
            if ~isfield(opt, 'LR') || ~isfield(opt.LR, 'BAS') || ~isfield(opt.LR.BAS, 'step'),  opt.LR.BAS.step     = 4;    end
            if ~isfield(opt, 'LR') || ~isfield(opt.LR, 'BAS') || ~isfield(opt.LR.BAS, 'n'),     opt.LR.BAS.n        = 50;   end
            if ~isfield(opt, 'LR') || ~isfield(opt.LR, 'BAS') || ~isfield(opt.LR.BAS, 'alpha'), opt.LR.BAS.alpha    = 0.2;  end
            if ~isfield(opt, 'LR') || ~isfield(opt.LR, 'BAS') || ~isfield(opt.LR.BAS, 'isLevy'),opt.LR.BAS.isLevy   = false;end
            optTune.BAS = opt.LR.BAS;
        case 'MLR'
            if ~isfield(opt, 'MLR') || ~isfield(opt.MLR, 'BAS') || ~isfield(opt.MLR.BAS, 'eta'),    opt.MLR.BAS.eta     = 0.95; end
            if ~isfield(opt, 'MLR') || ~isfield(opt.MLR, 'BAS') || ~isfield(opt.MLR.BAS, 'c'),      opt.MLR.BAS.c       = 5;    end
            if ~isfield(opt, 'MLR') || ~isfield(opt.MLR, 'BAS') || ~isfield(opt.MLR.BAS, 'step'),   opt.MLR.BAS.step    = 4;    end
            if ~isfield(opt, 'MLR') || ~isfield(opt.MLR, 'BAS') || ~isfield(opt.MLR.BAS, 'n'),      opt.MLR.BAS.n       = 50;   end
            if ~isfield(opt, 'MLR') || ~isfield(opt.MLR, 'BAS') || ~isfield(opt.MLR.BAS, 'alpha'),  opt.MLR.BAS.alpha   = 0.2;  end
            if ~isfield(opt, 'MLR') || ~isfield(opt.MLR, 'BAS') || ~isfield(opt.MLR.BAS, 'isLevy'), opt.MLR.BAS.isLevy  = false;end
            optTune.BAS = opt.MLR.BAS;
        case 'MLSSVR'
            if ~isfield(opt, 'MLSSVR') || ~isfield(opt.MLSSVR, 'BAS') || ~isfield(opt.MLSSVR.BAS, 'eta'),   opt.MLSSVR.BAS.eta      = 0.95; end
            if ~isfield(opt, 'MLSSVR') || ~isfield(opt.MLSSVR, 'BAS') || ~isfield(opt.MLSSVR.BAS, 'c'),     opt.MLSSVR.BAS.c        = 5;    end
            if ~isfield(opt, 'MLSSVR') || ~isfield(opt.MLSSVR, 'BAS') || ~isfield(opt.MLSSVR.BAS, 'step'),  opt.MLSSVR.BAS.step     = 2;    end
            if ~isfield(opt, 'MLSSVR') || ~isfield(opt.MLSSVR, 'BAS') || ~isfield(opt.MLSSVR.BAS, 'n'),     opt.MLSSVR.BAS.n        = 50;   end
            if ~isfield(opt, 'MLSSVR') || ~isfield(opt.MLSSVR, 'BAS') || ~isfield(opt.MLSSVR.BAS, 'alpha'), opt.MLSSVR.BAS.alpha    = 0.2;  end
            if ~isfield(opt, 'MLSSVR') || ~isfield(opt.MLSSVR, 'BAS') || ~isfield(opt.MLSSVR.BAS, 'isLevy'),opt.MLSSVR.BAS.isLevy   = false;end
            optTune.BAS = opt.MLSSVR.BAS;
    end
    if isfield(opt, 'show') && isfield(opt.show, 'isDraw') && opt.show.isDraw
        optTune.show.isDraw = opt.show.isDraw;
    end
    
    % calculate
    [xStore, fBestSeqBest, modelBest, foldBest] = MBAS(data, algoMode, init, optTune, []);
    [fBest, iterBest] = min(fBestSeqBest);
    para = xStore(2 : end - 1, iterBest);
    
    % print
    diary on;
    fprintf('               hyperparameter optimization results, ');
    switch algoMode
        case 'SVM'
            fprintf(['C: initial value is ' num2str(2^init(1)) ', recommended value for ' tuneMode ' is ' num2str(2^para(1))...
                 '; gamma: initial value is ' num2str(2^init(2)) ', recommended value for ' tuneMode ' is ' num2str(2^para(2))]);
        case 'LR'

        case 'MLR'

        case 'MLSSVR'
            fprintf(['gamma: initial value is ' num2str(init(1)) ', recommended value for ' tuneMode ' is ' num2str(para(1))...
                '; lambda: initial value is ' num2str(init(2)) ', recommended value for ' tuneMode ' is ' num2str(para(2))...
                '; p: initial value is ' num2str(2^init(3)) ', recommended value for ' tuneMode ' is ' num2str(2^para(3))]);
    end
    fprintf(['; The minimum error of verification set is reached in the ' num2str(iterBest) 'st iteration, the value is ' num2str(fBest)]);
	diary off;
        
    %% Plot
    if ~isfield(opt, 'show') || ~isfield(opt.show, 'isDraw') || opt.show.isDraw
        figurePara = setFigurePara(data.dataName, data.posOutput);
        figurePara.label.x = 'Iteration';
        figurePara.label.title = ['Convergence line of ' algoMode ' with different parameters while' tuneMode 'tuning'];
        figurePara.preserve.name = figurePara.label.title;
        figurePara.preserve.fold = ['savedFigure\' data.dataName '\' getOutputName(opt) '\' algoMode '\' tuneMode];
        if isfield(opt, 'show') && isfield(opt.show, 'isMSE') && opt.show.isMSE
            figurePara.label.y = figurePara.label.mse;
            figurePara.label.legend = {'Current MSE', 'Best known MSE'};
            lineData{1} = xStore(end,:);
            lineData{2} = fBestSeqBest';
        else
            figurePara.label.y = figurePara.label.rmse;
            figurePara.label.legend = {'Current RMSE', 'Best known RMSE'};
            lineData{1} = sqrt(xStore(end,:));
            lineData{2} = sqrt(fBestSeqBest)';
        end
        drawMultipleLine([],lineData, figurePara);
    end