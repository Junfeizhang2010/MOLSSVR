function [result, opt] = analysisModeChoose(data, opt)
    disp('�� model operation...');
    algoMode = opt.data.algoMode;
    tuneMode = opt.data.tuneMode;
    n = size(algoMode, 2);
    if data.yDimCount == 1
        for i = 1 : n
            disp(['       ' num2str(i) '/' num2str(n) ': running model ' algoMode{i} '...']);
            [evaRsTest, result.spandSecond(i), bestIterationMSE{i}, bestIterationRMSE{i}]...
                = analysisAlgorithm(data, tuneMode, algoMode{i}, opt);
            result.MSE(i)   = evaRsTest.MSE;
            result.RMSE(i)  = evaRsTest.RMSE;
            result.R(i)     = evaRsTest.R;
            result.R2(i)    = evaRsTest.R2;
            result.gap(i,:) = evaRsTest.gap;
            result.MAPE(i)  = evaRsTest.MAPE;
            result.MAE(i)   = evaRsTest.MAE;
            result.Std(i)   = evaRsTest.Std;   % Standard deviation of the predicted value of the test set
        end
        result.bestIterationMSE = bestIterationMSE;
        result.bestIterationRMSE = bestIterationRMSE;
    else
        for i = 1 : n
            disp(['       ' num2str(i) '/' num2str(n) ': running model ' algoMode{i} '...']);
            [evaRsTest, result.spandSecond(i), bestIterationMSE{i}, bestIterationRMSE{i}]...
                = analysisAlgorithm(data, tuneMode, algoMode{i}, opt);
            result.MSE{i}  = evaRsTest.MSE;
            result.RMSE{i} = evaRsTest.RMSE;
            result.R{i}    = evaRsTest.R;
            result.R2{i}   = evaRsTest.R2;
            result.gap{i}  = evaRsTest.gap;
            gapMin(:,i)    = evaRsTest.gapMin';
            result.MAPE{i} = evaRsTest.MAPE;
            result.MAE{i}  = evaRsTest.MAE;
            result.Std{i}  = evaRsTest.Std;
            result.MSEAve{i}  = evaRsTest.MSEAve;  
            result.RMSEAve{i} = evaRsTest.RMSEAve;
            result.RAve{i}    = evaRsTest.RAve;
            result.R2Ave{i}   = evaRsTest.R2Ave;
            result.MAPEAve{i} = evaRsTest.MAPEAve;
            result.MAEAve{i}  = evaRsTest.MAEAve;
            result.StdAve{i}  = evaRsTest.StdAve;
        end
        result.bestIterationMSE = bestIterationMSE;
        result.bestIterationRMSE = bestIterationRMSE;
    end

    %% analyze
    disp('�� analyze...');
    if ~isfield(opt, 'isAnalysis') || ~isfield(opt.isAnalysis, 'cmpMultiAlgo') || opt.isAnalysis.cmpMultiAlgo
        % Optimization process analysis
        if isfield(opt, 'show') && isfield(opt.show, 'isMSE') && opt.show.isMSE
            analysisTune(data, bestIterationMSE, algoMode, tuneMode, opt);
        else
            analysisTune(data, bestIterationRMSE, algoMode, tuneMode, opt);
        end

        % the performance of each model analysis with Taylor diagram
        if data.yDimCount == 1
            analysisBox(data, result.gap', algoMode, tuneMode, opt);
            analysisTaylor(data, result.Std, result.RMSE, result.R, algoMode, tuneMode, opt);
        else
            analysisBox(data, gapMin, algoMode, tuneMode, opt);
            analysisTaylor(data, mean(cell2mat(result.StdAve)), mean(cell2mat(result.RMSEAve)),...
                mean(cell2mat(result.RAve)), algoMode, tuneMode, opt);
        end
    end
    
    % save
    savePath = [getFold(mfilename('fullpath'), 2), 'savedData\'...
        opt.data.dataName '\' getOutputName(opt) '\' tuneMode '\conclusion'];