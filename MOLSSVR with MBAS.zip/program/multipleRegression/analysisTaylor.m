function analysisTaylor(data, Std, RMSE, R, algoMode, tuneMode, opt)
    figurePara = setFigurePara(data.dataName, data.posOutput);
    figurePara.label.title = 'Evaluation of Predicted and measured Values of Each Model';
    figurePara.preserve.fold = ['savedFigure\', data.dataName '\' getOutputName(opt) '\' tuneMode];
    if contains(tuneMode, 'PSO'), figurePara.preserve.fold = ['savedFigure\', data.dataName '\' getOutputName(opt) '\PSO']; end
    figurePara.preserve.name = figurePara.label.title;
    drawTaylor(mean(std(data.testYAllRow)), Std, RMSE, R, algoMode, figurePara);