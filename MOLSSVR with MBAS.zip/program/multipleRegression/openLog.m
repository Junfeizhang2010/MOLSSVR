function opt = openLog(opt)
    if ~isfield(opt, 'data') || ~isfield(opt.data, 'posOutput')
        opt.data.posOutput = 1;
    end
    if ~ischar(opt.data.dataName)
        dataName = opt.data.dataName{1};
    else
        dataName = opt.data.dataName;
    end
    savePath = [getFold(mfilename('fullpath'), 2), 'savedData\'...
        dataName '\' getOutputName(opt) '\' opt.data.tuneMode];
    createLog(savePath, 'log');