function [para, bestIterErr, model, bestFold] = tune(data, tuneMode, algoMode, opt)
    [para, bestIterErr, model, bestFold] = tuneNormal(data, tuneMode, algoMode, opt);