function time = printNow()
    time = clock;
    disp([num2str(time(1)), '-', num2str(time(2), '%02d'), '-', num2str(time(3), '%02d'), ' ',...
        num2str(time(4), '%02d'), ':', num2str(time(5), '%02d'), ':', num2str(round(time(6)), '%02d'), ])