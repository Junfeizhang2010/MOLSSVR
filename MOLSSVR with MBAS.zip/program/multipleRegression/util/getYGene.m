function str = getYGene(opt)
    figurePara = setFigurePara(opt.data.dataName, opt.data.posOutput);
    str = figurePara.label.yGene;
    str = deleteChar(str, {'/', '\'});
end