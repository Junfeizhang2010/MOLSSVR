function mape = getMape(x, y)
    mape = mean(abs(getGap(x, y) ./ y));