function mae = getMae(x, y)
    mae = mean(getGap(x, y));