function R = getR(x, y)
    R = min(min(corrcoef(x, y)));