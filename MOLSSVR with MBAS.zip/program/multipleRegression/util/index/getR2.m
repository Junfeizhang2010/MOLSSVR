function R2 = getR2(x, y)
    R2 = getR(x, y)^2;