function mse = getMse(x, y)
    mse = mean((x - y).^2);