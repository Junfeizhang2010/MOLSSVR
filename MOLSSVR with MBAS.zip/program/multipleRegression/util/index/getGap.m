function gap = getGap(x, y)
    gap = abs(x - y);