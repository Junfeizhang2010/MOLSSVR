function RMSE = getRmse(x, y)
    RMSE = sqrt(getMse(x, y));