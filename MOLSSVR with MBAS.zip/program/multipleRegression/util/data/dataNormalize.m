function data = dataNormalize(data)
    % Normalized eigenvalues
    xAllNorm = data.xAll;
    for i = 1 : data.xDimCount
        xNormPara(i) = max(abs(xAllNorm(:,i)));
        xAllNorm(:,i) = xAllNorm(:,i) ./ xNormPara(i);
    end
    data.xNormPara = xNormPara;
    data.xAllNorm = xAllNorm;
    data.xAllNormColumn = xAllNorm';
    data.xNormMax = max(xAllNorm);
    data.xNormMin = min(xAllNorm);
    data.allNorm = [xAllNorm, data.yAll];
    data.allNormPara = [xNormPara, 1];
    
    % Normalized target value
    if isfield(data, 'isNormY') && data.isNormY || data.yDimCount > 1
        yAllNorm = data.yAll;
        for i = 1 : data.yDimCount
            yNormPara(i) = max(abs(yAllNorm(:,i)));
            yAllNorm(:,i) = yAllNorm(:,i) ./ max(abs(yAllNorm(:,i)));
        end
        data.yNormPara = yNormPara;
        data.yAllNorm = yAllNorm;
        data.yAllNormColumn = yAllNorm';
        data.yNormMax = max(yAllNorm);
        data.yNormMin = min(yAllNorm);
        data.xyAllNorm = [xAllNorm, yAllNorm];
        data.allNorm = data.xyAllNorm;
        data.allNormPara = [xNormPara, yNormPara];
        data.allNormMax = [data.xNormMax, data.yNormMax];
        data.allNormMin = [data.xNormMin, data.yNormMin];
    end