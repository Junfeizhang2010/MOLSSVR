function data = getCross(data, dataMode)
    yAll = data.yAll;
    switch dataMode
        case 'all'
            if isfield(data, 'xAllNormColumn')
                tempXColumn = data.xAllNormColumn;
            else
                tempXColumn = data.xAllColumn;
            end
            tempYColumn = data.yAllColumn;
            if data.yDimCount == 1 && isequal(yAll, fix(yAll)) && ~isempty(find(yAll==1, 1))
                tempYClassColumn = data.yAllClassColumn;
            end
        case 'train'
            tempXColumn = data.trainXAllColumn;
            tempYColumn = data.trainYAllColumn;
            if data.yDimCount == 1 && isequal(yAll, fix(yAll)) && ~isempty(find(yAll==1, 1))
                tempYClassColumn = data.trainYAllClassColumn;
            end
        case 'test'
            tempXColumn = data.testXAllColumn;
            tempYColumn = data.testYAllColumn;
            if data.yDimCount == 1 && isequal(yAll, fix(yAll)) && ~isempty(find(yAll==1, 1))
                tempYClassColumn = data.testYAllClassColumn;
            end
    end
    
    crossCount = data.crossCount;
    n = size(tempXColumn, 2);
    randIdx = randperm(n);
    for i = 1 : crossCount
        b = round((i - 1) / crossCount * n) + 1;
        e = round(i / crossCount * n);
        data.validationCount(i) = e - b + 1;
        crossColumn{i}.testX    = tempXColumn(:, randIdx(b:e));
        crossColumn{i}.testY    = tempYColumn(:, randIdx(b:e));
        crossColumn{i}.trainX   = tempXColumn(:, randIdx([1:b-1 e+1:end]));
        crossColumn{i}.trainY   = tempYColumn(:, randIdx([1:b-1 e+1:end]));
        crossRow{i}.testX       = crossColumn{i}.testX';
        crossRow{i}.testY       = crossColumn{i}.testY';
        crossRow{i}.trainX      = crossColumn{i}.trainX';
        crossRow{i}.trainY      = crossColumn{i}.trainY';
    end
    
    switch dataMode
        case 'all'
            data.allCrossColumn = crossColumn;
            data.allCrossRow = crossRow;
            if data.yDimCount == 1 && isequal(yAll, fix(yAll)) && ~isempty(find(yAll==1, 1))
                data.allCrossClassColumn = crossClassColumn;
                data.allCrossClassRow = crossClassRow;
            end
        case 'train'
            data.trainCrossColumn = crossColumn;
            data.trainCrossRow = crossRow;
            if data.yDimCount == 1 && isequal(yAll, fix(yAll)) && ~isempty(find(yAll==1, 1))
                data.trainCrossClassColumn = crossClassColumn;
                data.trainCrossClassRow = crossClassRow;
            end
        case 'test'
            data.testCrossColumn = crossColumn;
            data.testCrossRow = crossRow;
            if data.yDimCount == 1 && isequal(yAll, fix(yAll)) && ~isempty(find(yAll==1, 1))
                data.testCrossClassColumn = crossClassColumn;
                data.testCrossClassRow = crossClassRow;
            end
    end