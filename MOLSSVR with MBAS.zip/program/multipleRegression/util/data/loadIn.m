function data = loadIn(data)
	path = mfilename('fullpath');
	i = findstr(path,'\');
    path = path(1 : i(end - 4));
    folderPath = [path, 'dataset\'];
	
    if ~isfield(data, 'all') 
        switch data.dataName
            case 'SA'
                all = xlsread([folderPath, 'SA.xlsx']);
        end
    else
        all = data.all;
    end
    if ~isfield(data, 'isTranspose') || ~data.isTranspose
        data.all = all;
    else
        data.all = all';
    end
    [data.count, data.dimCount] = size(all);
    data.allMax = max(all);
    data.allMin = min(all);