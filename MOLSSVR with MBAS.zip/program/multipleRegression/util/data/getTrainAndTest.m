function data = getTrainAndTest(data)
    if isfield(data, 'xAllNorm')
        xAll = data.xAllNorm;
    else
        xAll = data.xAll;
    end
    if isfield(data, 'yAllNorm')
        yAll = data.yAllNorm;
    else
        yAll = data.yAll;
    end
    trainProp = data.trainPer;
    assert(trainProp <= 1, 'Proportion is wrong');
    
    count      = data.count;
    trainCount = round(trainProp * count);
    
    randIdx = randperm(count);

    data.trainXAllRow = xAll(randIdx(1 : trainCount), :);
    data.trainYAllRow = yAll(randIdx(1 : trainCount), :);
    if trainCount < count
        data.testXAllRow = xAll(randIdx(trainCount + 1 : count), :);
        data.testYAllRow = yAll(randIdx(trainCount + 1 : count), :);
    else
        data.testXAllRow = [];
        data.testYAllRow = [];
    end
    
    
    data.trainXAllColumn = data.trainXAllRow';
    data.trainYAllColumn = data.trainYAllRow';
    if data.yDimCount == 1 && isequal(yAll, fix(yAll)) && ~isempty(find(yAll==1, 1))
        data.trainYAllClassColumn = data.trainYAllClassRow';
    end
    data.testXAllColumn  = data.testXAllRow';
    data.testYAllColumn  = data.testYAllRow';
    if data.yDimCount == 1 && isequal(yAll, fix(yAll)) && ~isempty(find(yAll==1, 1))
        data.testYAllClassColumn = data.testYAllClassRow';
    end

    data.trainCount = trainCount;
    data.testCount = data.count - trainCount;