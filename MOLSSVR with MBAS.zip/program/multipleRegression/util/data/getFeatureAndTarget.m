function data = getFeatureAndTarget(data)
    all = data.all;
    
    % eigenvalue
    posLastInput = data.posLastInput;
    if length(posLastInput) == 1
        xAll = all(:, 1 : end - posLastInput + 1);
        data.xMax = data.allMax(1 : end - posLastInput + 1);
        data.xMin = data.allMin(1 : end - posLastInput + 1);
    else
        xAll = all(:,posLastInput);
        data.xMax = data.allMax(posLastInput);
        data.xMin = data.allMin(posLastInput);
    end
    [~, data.xDimCount] = size(xAll);
    data.xAll = xAll;
    data.xAllColumn = xAll';
    
    % target value
    yAll = all(:, end - fliplr(data.posOutput) + 1);   % fliplr�� flip left and right
    data.yMax = data.allMax(end - fliplr(data.posOutput) + 1);
    data.yMin = data.allMin(end - fliplr(data.posOutput) + 1);
    [~, data.yDimCount] = size(yAll);
    data.yAll = yAll;
    data.yAllColumn = yAll';
    data.xyAll = [data.xAll, data.yAll];