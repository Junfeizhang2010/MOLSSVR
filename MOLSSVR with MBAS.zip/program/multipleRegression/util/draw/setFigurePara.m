function figurePara = setFigurePara(dataName, posOutput)
    if isempty(posOutput), posOutput = 1; end
    font.name = 'Times new roman';
    font.size = 16;
    font.weight = 'bold';
    figurePara.font = font;
    
    figurePara.wire.width = 2;
    
    figurePara.show.digits = 4;
    
    if ~isempty(dataName)
        label.ucs = 'UCS (MPa)';
        label.ts = 'TS (MPa)';
        switch dataName
            case 'SA'
                label.yGene = {label.ucs, label.ts};
                label.input = {'Age', 'Dmax', 'SPC', 'FMS', 'W/B', 'W/C', 'SR'};
        end
        if ~isfield(label, 'input2')
            label.input2 = label.input;
        end
        if length(posOutput) <= 1
            label.yGene = label.yGene{posOutput};
        else
            for i = 1 : length(posOutput)
                temp{i} = label.yGene{posOutput(i)};
            end
            label.yGene = temp;
        end
    
        % label.mse = 'Mean Squared Error';
        label.mse = 'MSE';
        label.rmse = 'RMSE';

        label.residual = 'Residual';
        label.xGene = 'Data Number';

        if length(posOutput) <= 1
            label.output = label.yGene;
        else
            label.output = 'Multiple';
        end
        label.all = label.input;
        label.all{1, length(label.input) + 1} = label.output;

        label.predicted = 'Predicted';
        label.experimental = 'Actual';
        
        if ischar(label.yGene)
            label.y = [label.predicted ' ' label.yGene];
            label.x = [label.experimental ' ' label.yGene];
        else
            for i = 1 : length(label.yGene)
                label.y{i} = [label.predicted ' ' label.yGene{i}];
                label.x{i} = [label.experimental ' ' label.yGene{i}];
            end
        end
        figurePara.label = label;
    end