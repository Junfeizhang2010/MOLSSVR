function f = drawRegression2(trainX, trainY, testX, testY, figurePara)
    
    font = figurePara.font;
    label = figurePara.label;
    if isfield(figurePara, 'trainMarker'), trainMarker = figurePara.trainMarker; end
    if ~isfield(figurePara, 'trainMarker') || ~isfield(trainMarker, 'shape'), trainMarker.shape = 's'; end
    if isfield(figurePara, 'trainMarker') && isfield(trainMarker, 'size'), trainMarker.size = trainMarker.size * 8; else, trainMarker.size = 36; end
    if ~isfield(figurePara, 'trainMarker') || ~isfield(trainMarker, 'faceColor'), trainMarker.faceColor = 'b'; end
    
    if isfield(figurePara, 'testMarker'), testMarker = figurePara.testMarker; end
    if ~isfield(figurePara, 'testMarker') || ~isfield(testMarker, 'shape'), testMarker.shape = 'h'; end
    if isfield(figurePara, 'testMarker') && isfield(testMarker, 'size'), testMarker.size = testMarker.size * 8; else, testMarker.size = 48; end
    if ~isfield(figurePara, 'testMarker') || ~isfield(testMarker, 'faceColor'), testMarker.faceColor = 'r'; end
    
    figurePara.show.title = isfield(figurePara, 'show') && isfield(figurePara.show, 'title');
    show = figurePara.show;
    if ~isfield(show, 'digits'), digits = 3; else, digits = show.digits; end
    if ~isfield(figurePara, 'preserve') || ~isfield(figurePara.preserve, 'is')
        figurePara.preserve.is = isfield(figurePara, 'preserve') && isfield(figurePara.preserve, 'name');
    end
    preserve = figurePara.preserve;
    
    f = figure('NumberTitle', 'off', 'Name', label.title);hold on;
    scatter(trainX, trainY, trainMarker.size, trainMarker.faceColor, trainMarker.shape, 'filled');
    scatter(testX, testY, testMarker.size, testMarker.faceColor, testMarker.shape, 'filled');
    l = min([min(trainX), min(trainY), min(testX), min(testY)]) * 0.99;
    h = max([max(trainX), max(trainY), max(testX), max(testY)]) * 1.01;
    plot(linspace(l,h,100), linspace(l,h,100), 'k');
    axis([l h l h]);
    xlabel(label.x); ylabel(label.y);
    if isfield(figurePara, 'data') && isfield(figurePara.data, 'isMse') && figurePara.data.isMse
        t1 = text((h - l) * 0.05 + l, (h - l) * 0.9 + l, ['Training Set MSE = ' num2str(round(getMse(trainX, trainY), digits))]);
        t2 = text((h - l) * 0.05 + l, (h - l) * 0.74 + l, ['Test Set MSE = ' num2str(round(getMse(testX, testY), digits))]);
    else
        t1 = text((h - l) * 0.05 + l, (h - l) * 0.9 + l, ['Training Set RMSE = ' num2str(round(getRmse(trainX, trainY), digits))]);
        t2 = text((h - l) * 0.05 + l, (h - l) * 0.74 + l, ['Test Set RMSE = ' num2str(round(getRmse(testX, testY), digits))]);
    end
    if ~isfield(figurePara, 'data') || ~isfield(figurePara.data, 'isR') || figurePara.data.isR
        t3 = text((h - l) * 0.05 + l,(h - l) * 0.82 + l,['Training Set R = ' num2str(round(getR(trainX, trainY), digits))]);
        t4 = text((h - l) * 0.05 + l,(h - l) * 0.66 + l,['Test Set R = ' num2str(round(getR(testX, testY), digits))]);
    else
        t3 = text((h - l) * 0.05 + l,(h - l) * 0.82 + l,['Training Set R^2 = ' num2str(round(getR2(trainX, trainY), digits))]);
        t4 = text((h - l) * 0.05 + l,(h - l) * 0.66 + l,['Test Set R^2 = ' num2str(round(getR2(testX, testY), digits))]);
    end
    l = legend({'Training Set', 'Test Set'}, 'Location', 'SouthEast'); set(l, 'Box', 'off');
    set(t1, 'Fontname', font.name, 'FontSize', font.size, 'FontWeight', font.weight);
    set(t2, 'Fontname', font.name, 'FontSize', font.size, 'FontWeight', font.weight);
    set(t3, 'Fontname', font.name, 'FontSize', font.size, 'FontWeight', font.weight);
    set(t4, 'Fontname', font.name, 'FontSize', font.size, 'FontWeight', font.weight);
    if show.title == true, title(label.title); end
    set(gca, 'Fontname', font.name, 'FontSize', font.size, 'FontWeight', font.weight, 'Box', 'on');
    if preserve.is, preserveFigure(figurePara.preserve.fold, preserve.name); end