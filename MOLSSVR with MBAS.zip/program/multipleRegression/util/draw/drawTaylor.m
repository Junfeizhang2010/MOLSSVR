function h = drawTaylor(obStd, Std, RMSE, R, algoMode, figurePara)
    font = figurePara.font;
    label = figurePara.label;
    
    figurePara.show.title = isfield(figurePara, 'show') && isfield(figurePara.show, 'title');
    show = figurePara.show;
    if ~isfield(figurePara, 'preserve') || ~isfield(figurePara.preserve, 'is')
        figurePara.preserve.is = isfield(figurePara, 'preserve') && isfield(figurePara.preserve, 'name');
    end
    preserve = figurePara.preserve;
    
    h = figure('NumberTitle', 'off', 'Name', label.title);hold on;
    taylor_diagram([obStd, Std], RMSE, [1, R], 'styleOBS', '-', 'colOBS', 'k',...
        'markerobs', 'o', 'titleOBS', 'Actural', 'markerlabel',...
        cellInsert1(algoMode, '', 1), 'markerLabelColor', 'r');
    set(get(gca,'XLabel'),'FontSize',12);
    set(get(gca,'YLabel'),'FontSize',12);
    if show.title == true, title(label.title); end
    if preserve.is == true, preserveFigure(figurePara.preserve.fold, preserve.name); end