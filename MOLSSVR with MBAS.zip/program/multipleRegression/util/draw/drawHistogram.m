function h = drawHistogram(data, figurePara)
    font = figurePara.font;
    label = figurePara.label;
    
    if ~isfield(figurePara, 'rectangle') || ~isfield(figurePara.rectangle, 'FaceColor'), figurePara.rectangle.FaceColor = 'y'; end
    if ~isfield(figurePara, 'rectangle') || ~isfield(figurePara.rectangle, 'EdgeColor'), figurePara.rectangle.EdgeColor = 'k'; end
    if ~isfield(figurePara, 'subline') || ~isfield(figurePara.subline, 'color'), figurePara.subline.color = [0.5 0.5 0.5]; end
    if ~isfield(figurePara, 'subline') || ~isfield(figurePara.subline, 'style'), figurePara.subline.style = '--'; end
    
    if ~isfield(figurePara, 'show') || ~isfield(figurePara.show, 'wire'), figurePara.show.wire = 'min'; end
    figurePara.show.wireText = isfield(figurePara, 'show') && isfield(figurePara.show, 'wireText');
    figurePara.show.title = isfield(figurePara, 'show') && isfield(figurePara.show, 'title');
    show = figurePara.show;
    if ~isfield(show, 'digits'), digits = 3; else, digits = show.digits; end
    if ~isfield(figurePara, 'preserve') || ~isfield(figurePara.preserve, 'is')
        figurePara.preserve.is = isfield(figurePara, 'preserve') && isfield(figurePara.preserve, 'name');
    end
    preserve = figurePara.preserve;
    
    h = figure('NumberTitle', 'off', 'Name', label.title);hold on;
    bar(1 : length(data), data, 'FaceColor', figurePara.rectangle.FaceColor, 'EdgeColor', figurePara.rectangle.EdgeColor);
    switch show.wire
        case 'min', [lineData, lineIdx] = min(data);
        case 'max', [lineData, lineIdx] = max(data);
    end
    plot(0 : length(data) + 1, ones(length(data) + 2) * data(lineIdx), figurePara.subline.style, 'color', figurePara.subline.color);
    if figurePara.show.wireText
        text(lineIdx - 0.4, lineData * 1.3, num2str(round(lineData, digits)));
    end
    xlabel(label.x); ylabel(label.y);
    if min(data) > 0
        axis([0.5, length(data) + 0.5, 0, max(data) * 1.1]);
    elseif max(data) < 0
        axis([0.5, length(data) + 0.5, max(data) * 1.1, 0]);
    end
    set(gca,'Xtick',1:10);
    if show.title == true, title(label.title); end
    set(gca, 'Fontname', font.name, 'FontSize', font.size, 'FontWeight', font.weight, 'Box', 'on');
    if preserve.is == true, preserveFigure(figurePara.preserve.fold, preserve.name); end