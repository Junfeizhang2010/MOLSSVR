function h = drawBox(data, figurePara)
    font = figurePara.font;
    label = figurePara.label;
    
    figurePara.show.title = isfield(figurePara, 'show') && isfield(figurePara.show, 'title');
    show = figurePara.show;
    if ~isfield(figurePara, 'preserve') || ~isfield(figurePara.preserve, 'is')
        figurePara.preserve.is = isfield(figurePara, 'preserve') && isfield(figurePara.preserve, 'name');
    end
    preserve = figurePara.preserve;
    
    h = figure('NumberTitle', 'off', 'Name', label.title);hold on;
    boxplot(data, 'labels', label.x);
    ylabel(label.y);
    if show.title == true, title(label.title); end
    set(gca, 'Fontname', font.name, 'FontSize', font.size, 'FontWeight', font.weight, 'Box', 'on');
    if preserve.is == true, preserveFigure(figurePara.preserve.fold, preserve.name); end