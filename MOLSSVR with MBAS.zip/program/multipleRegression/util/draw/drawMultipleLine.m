function drawMultipleLine(x, y, figurePara)
    font = figurePara.font;
    label = figurePara.label;
    wire = figurePara.wire;
    
    if ~isfield(figurePara, 'legend') || ~isfield(figurePara.legend, 'location'), figurePara.legend.location = 'NorthEast'; end
    figurePara.show.title = isfield(figurePara, 'show') && isfield(figurePara.show, 'title');
    show = figurePara.show;
    if ~isfield(figurePara, 'preserve') || ~isfield(figurePara.preserve, 'is')
        figurePara.preserve.is = isfield(figurePara, 'preserve') && isfield(figurePara.preserve, 'name');
    end
    preserve = figurePara.preserve;
    
    k = length(y);
    figure('NumberTitle', 'off', 'Name', label.title);hold on;
    colors = {'b','r','k',[0.75 0.75 0],'m','g',[0.5 0.5 0.5]};
    markers = {'o','s','^','p','*','+','h'};
    maxX = 0;
    setXlim = false;
    for i = 1 : k
        if ~isempty(y{i})
            n = length(y{i});
            if isempty(x) || length(x) < i || isempty(x{i})
                x{i} = 1 : n;
                setXlim = true;
            end
            if i < 8
                plot(x{i}, y{i}, 'Color', colors{i}, 'LineWidth', wire.width);
            else
                plot(x{i}, y{i}, 'LineWidth', wire.width);
            end
            if max(x{i}) > maxX, maxX = max(x{i}); end
        end
    end
    l = legend(label.legend, 'Location', figurePara.legend.location); set(l, 'Box', 'off');
    xlabel(label.x); ylabel(label.y);
    if setXlim, set(gca,'xlim',[0, maxX + 1]); end
    if show.title == true, title(label.title); end
    set(gca, 'Fontname', font.name, 'FontSize', font.size, 'FontWeight', font.weight, 'Box', 'on');
    if preserve.is == true, preserveFigure(figurePara.preserve.fold, preserve.name); end