function f = drawRegression(X, Y, figurePara)
    font = figurePara.font;
    label = figurePara.label;
    if isfield(figurePara, 'marker'), marker = figurePara.marker; end
    if ~isfield(figurePara, 'marker') || ~isfield(marker, 'shape'), marker.shape = 's'; end
    if isfield(figurePara, 'marker') && isfield(marker, 'size'), marker.size = marker.size * 8; else, marker.size = 48; end
    if ~isfield(figurePara, 'marker') || ~isfield(marker, 'faceColor'), marker.faceColor = 'r'; end
    
    figurePara.show.title = isfield(figurePara, 'show') && isfield(figurePara.show, 'title');
    show = figurePara.show;
    if ~isfield(show, 'digits'), digits = 3; else, digits = show.digits; end
    if ~isfield(figurePara, 'preserve') || ~isfield(figurePara.preserve, 'is')
        figurePara.preserve.is = isfield(figurePara, 'preserve') && isfield(figurePara.preserve, 'name');
    end
    preserve = figurePara.preserve;
    
    f = figure('NumberTitle', 'off', 'Name', label.title);hold on;
    scatter(X, Y, marker.size, marker.faceColor, marker.shape, 'filled');
    l = min([min(X), min(Y)]) * 0.99;
    h = max([max(X), max(Y)]) * 1.01;
    plot(linspace(l,h,100), linspace(l,h,100), 'k');
    axis([l h l h]);
    xlabel(label.x); ylabel(label.y);
    if isfield(figurePara, 'data') && isfield(figurePara.data, 'isMse') && figurePara.data.isMse
        t1 = text((h - l) * 0.05 + l,(h - l) * 0.9 + l,['MSE = ' num2str(round(getMse(X, Y), digits))]);
    else
        t1 = text((h - l) * 0.05 + l,(h - l) * 0.9 + l,['RMSE = ' num2str(round(getRmse(X, Y), digits))]);
    end
    if ~isfield(figurePara, 'data') || ~isfield(figurePara.data, 'isR') || figurePara.data.isR
        t2 = text((h - l) * 0.05 + l,(h - l) * 0.82 + l,['R = ' num2str(round(getR(X, Y), digits))]);
    else
        t2 = text((h - l) * 0.05 + l,(h - l) * 0.82 + l,['R^2 = ' num2str(round(getR2(X, Y), digits))]);
    end
    set(t1, 'Fontname', font.name, 'FontSize', font.size, 'FontWeight', font.weight);
    set(t2, 'Fontname', font.name, 'FontSize', font.size, 'FontWeight', font.weight);
    if show.title == true, title(label.title); end
    set(gca, 'Fontname', font.name, 'FontSize', font.size, 'FontWeight', font.weight, 'Box', 'on');
    if preserve.is == true, preserveFigure(figurePara.preserve.fold, preserve.name); end