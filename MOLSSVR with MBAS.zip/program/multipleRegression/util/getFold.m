function path = getFold(path, backNo)
    if strcmp(path(end) ,'/')
        path = path(1 : end - 1);
    end
    i = findstr(path, '\');
    path = path(1 : i(end - backNo + 1));