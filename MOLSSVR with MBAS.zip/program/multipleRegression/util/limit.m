function x = limit(x, algoMode)
    switch algoMode
        case {'LR'}
            x = round(x);
            x(x < 1) = 1;
    end