function createLog(logFold, logFile)
    mkdir(logFold);
    logFile = [logFold '\' logFile '.txt'];
    fopen(logFile, 'w');
    diary(logFile);