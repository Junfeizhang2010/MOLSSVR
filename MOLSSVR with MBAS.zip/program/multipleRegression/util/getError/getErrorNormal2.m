function [result, predicted, model] = getErrorNormal2(data, model, para, algoMode, crossIndex)
    switch crossIndex
        case 'test'
            trainX = data.trainXAllRow;
            trainY = data.trainYAllRow;
            testX = data.testXAllRow;
            experimental = data.testYAllRow;
        case 'train'
            trainX = data.trainXAllRow;
            trainY = data.trainYAllRow;
            testX = data.trainXAllRow;
            experimental = data.trainYAllRow;
        otherwise
            trainX = data.trainCrossRow{crossIndex}.trainX;
            trainY = data.trainCrossRow{crossIndex}.trainY;
            testX = data.trainCrossRow{crossIndex}.testX;
            experimental = data.trainCrossRow{crossIndex}.testY;
    end
    
    % train
    if isempty(model)
        if isempty(para)
            switch algoMode
                case 'SVM'
                    model = svmtrain(trainY, trainX, ['-s 3']);   % -s 3��epsilon-SVR
                case 'LR' 
                    temp = mapminmax(trainY', 0, 1); % normalized trainY
                    trainY = temp';
                    model = glmfit(trainX, [trainY, ones(size(trainY))], 'binomial', 'link', 'logit');
                 case 'MLR'
                    MLRX = [ones(size(trainX, 1), 1), trainX];
                    model = regress(trainY, MLRX);
            end
        else
            switch algoMode
                case 'SVM'
                    model = svmtrain(trainY, trainX, ['-s 3 -c ', ...   % -s 3��epsilon-SVR
                        num2str(2^para(1)), ' -g ', num2str(2^para(2))]);
                case 'LR' 
                    temp = mapminmax(trainY', 0, 1); % normalized trainY
                    trainY = temp';
                    model = glmfit(trainX, [trainY, ones(size(trainY))], 'binomial', 'link', 'logit');
                case 'MLR'
                    MLRX = [ones(size(trainX, 1), 1), trainX];
                    model = regress(trainY, MLRX);
            end
        end
    end
    
    % predict
    switch algoMode
        case 'SVM'
            predicted = svmpredict(experimental, testX, model);
        case 'LR'
            [~, PS] = mapminmax(experimental', 0, 1);  % normalized
            predicted = glmval(model, testX, 'probit', 'size', ones(size(experimental)));
            temp = mapminmax('reverse', predicted', PS);  % reverse normalized
            predicted = temp';
        case 'MLR'
            predicted = [ones(size(testX, 1), 1), testX] * model;
        otherwise
            predicted = predict(model, testX);
    end
    result.MSE     = getMse(predicted, experimental);
    result.RMSE    = getRmse(predicted, experimental);
    result.R       = getR(predicted, experimental);
    result.R2      = getR2(predicted, experimental);
    result.gap     = getGap(predicted, experimental);
    result.MAE     = getMae(predicted, experimental);
    result.MAPE    = getMape(predicted, experimental);
    result.Std     = std(predicted);
    predicted = predicted';