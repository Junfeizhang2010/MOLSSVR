function [err, model, figLine] = getError(data, crossIndex, algoMode, x, others)
    switch algoMode
        case 'MLSSVR'
            addpath(genpath([getFold(mfilename('fullpath'), 4) 'MLUtil\LSSVM']));
            [errRt, ~, model] = getErrorNormalMultiple(data, [], x, algoMode, crossIndex);
            err = errRt.MSEAve;
            figLine = err;
        otherwise
            addpath(genpath([getFold(mfilename('fullpath'), 4) 'MLUtil\LSSVM']));
            [errRt, ~, model] = getErrorNormal2(data, [], x, algoMode, crossIndex);
            err = errRt.MSE;
            figLine = err;
    end