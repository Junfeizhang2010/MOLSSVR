function [result, predicted, model] = getErrorNormalMultiple(data, model, para, algoMode, crossIndex, bestFold)
    switch crossIndex
        case 'test'
            trainX = data.trainCrossRow{bestFold}.trainX;
            trainY = data.trainCrossRow{bestFold}.trainY;
            testX = data.testXAllRow;
            experimental = data.testYAllRow;
        case 'train'
            trainX = data.trainCrossRow{bestFold}.trainX;
            trainY = data.trainCrossRow{bestFold}.trainY;
            testX = data.trainXAllRow;
            experimental = data.trainYAllRow;
        otherwise
            trainX = data.trainCrossRow{crossIndex}.trainX;
            trainY = data.trainCrossRow{crossIndex}.trainY;
            testX = data.trainCrossRow{crossIndex}.testX;
            experimental = data.trainCrossRow{crossIndex}.testY;
    end
    
    % train
    if isempty(model)
        if isempty(para)
            switch algoMode
                case 'MLSSVR'
                    trainX = data.trainXAllRow;
                    trainY = data.trainYAllRow;
                    [model.alpha, model.b] = MLSSVRTrain(trainX, trainY, 0.5, 4, 2);
                    model.lambda = 4;
                    model.p = 2;
            end
        else
            switch algoMode
                case 'MLSSVR'
                    [model.alpha, model.b] = MLSSVRTrain(trainX, trainY, para(1), para(2), 2^para(3));   % gamma, lambda, p
                    model.lambda = para(2);
                    model.p = 2^para(3);
            end
        end
    end
    
    % predict
    switch algoMode
        case 'MLSSVR'
            predicted = MLSSVRPredict(testX, experimental, trainX, model.alpha, model.b, model.lambda, model.p);
    end
    n = data.yDimCount;
    MSEAll = 0;
    RMSEAll = 0;
    RAll = 0;
    R2All = 0;
    gapM = inf;
    MAEAll = 0;
    MAPEAll = 0;
    StdAll = 0;
    for t = 1 : n
        result.MSE{t}   = getMse(predicted(:, t), experimental(:, t));
        MSEAll          = MSEAll + result.MSE{t};
        result.RMSE{t}  = getRmse(predicted(:, t), experimental(:, t));
        RMSEAll         = RMSEAll + result.RMSE{t};
        result.R{t}     = getR(predicted(:, t), experimental(:, t));        
        RAll            = RAll + result.R{t};
        result.R2{t}    = getR2(predicted(:, t), experimental(:, t));
        R2All           = R2All + result.R2{t};
        result.gap{t}   = getGap(predicted(:, t), experimental(:, t));
        result.gapMin   = result.gap{t};
        if mean(result.gap{t}) < gapM
            gapM          = mean(result.gap{t});
            result.gapMin = result.gap{t};
        end
        result.MAE{t}   = getMae(predicted(:, t), experimental(:, t));
        MAEAll          = MAEAll + result.MAE{t};
        result.MAPE{t}  = getMape(predicted(:, t), experimental(:, t));
        MAPEAll         = MAPEAll + result.MAPE{t};
        result.Std{t}   = std(predicted(:, t));
        StdAll          = StdAll + result.Std{t};
    end
    result.MSEAve  = MSEAll / n;    
    result.RMSEAve = RMSEAll / n;
    result.RAve    = RAll / n;
    result.R2Ave   = R2All / n;
    result.MAEAve  = MAEAll / n;
    result.MAPEAve = MAPEAll / n;
    result.StdAve  = StdAll / n;
    predicted      = predicted';