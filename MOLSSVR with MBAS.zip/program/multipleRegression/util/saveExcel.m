function saveExcel(result, columnItem, rowItem, savePath, sheetName)
    folderPath = getFold(savePath, 1);
    if ~exist(folderPath, 'file')
        mkdir(folderPath);
    end
    if isempty(columnItem) && isempty(rowItem)
        if isempty(sheetName)
            xlswrite([savePath '.xlsx'], num2cell(result));
        else
            xlswrite([savePath '.xlsx'], num2cell(result), sheetName);
        end
    elseif isempty(columnItem) && ~isempty(rowItem)
        if isempty(sheetName)
            xlswrite([savePath '.xlsx'], [rowItem, num2cell(result)]);
        else
            xlswrite([savePath '.xlsx'], [rowItem, num2cell(result)], sheetName);
        end
    elseif ~isempty(columnItem) && isempty(rowItem)
        if isempty(sheetName)
            xlswrite([savePath '.xlsx'], [columnItem; num2cell(result)]);
        else
            xlswrite([savePath '.xlsx'], [columnItem; num2cell(result)], sheetName);
        end
    else
        [m, n] = size(result);
        resultCell = mat2cell(result, ones(m,1), ones(n,1));
        if isempty(sheetName)
            xlswrite([savePath '.xlsx'], [[repmat({' '}, size(columnItem,1), size(rowItem,2)); rowItem], [columnItem; resultCell]]);
        else
            xlswrite([savePath '.xlsx'], [[repmat({' '}, size(columnItem,1), size(rowItem,2)); rowItem], [columnItem; resultCell]], sheetName);
        end
    end