function str = getOutputName(opt)
    if ischar(opt.data.dataName)
        dataName = opt.data.dataName;
    else
        dataName = opt.data.dataName{1};
    end
    figurePara = setFigurePara(dataName, opt.data.posOutput);
    str = figurePara.label.output;
    str = deleteChar(str, {'/', '\'});
end