function result = expRegression(opt)
    opt = openLog(opt);
    diary on;    disp(['���� Data set: ' opt.data.dataName ' ����    MBAS-MOLSSVR']);   fprintf('start at ');    opt.beginTime = printNow();    diary off;  
    
    %% load data
    if ~isfield(opt, 'data') || ~isfield(opt.data, 'data')
        data = loadData(opt);
    else
        data = opt.data.data;
    end

    if ~isfield(opt, 'isAnalysis') || ~isfield(opt.isAnalysis, 'modeChoose') || opt.isAnalysis.modeChoose
        [result, opt] = analysisModeChoose(data, opt);
    end
    
    diary on;    fprintf('end at ');    opt.endTime = printNow();    diary off;
    fclose('all');