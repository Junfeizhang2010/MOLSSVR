function [evaRsTest, evaRsTrain] = evaluate2(data, model, tuneMode, algoMode, para, bestFold, opt)
    
    %% Training and testing
    disp(['            �� evaluate model ' algoMode '...']);
    switch algoMode
        case 'MLSSVR'
            [evaRsTrain,  predictedTrain] = getErrorNormalMultiple(data, model, [], algoMode, 'train', bestFold);
            [evaRsTest, predictedTest] = getErrorNormalMultiple(data, model, [], algoMode, 'test', bestFold);
        otherwise
            [evaRsTrain, predictedTrain] = getErrorNormal2(data, model, [], algoMode, 'train');
            [evaRsTest, predictedTest] = getErrorNormal2(data, model, [], algoMode, 'test');
    end
    
    %% draw
    if isempty(opt) || ~isfield(opt, 'show') || ~isfield(opt.show, 'isDraw') || opt.show.isDraw
        % regression figure of training set
        figurePara = setFigurePara(data.dataName, data.posOutput);
        figurePara.data.isR = isempty(opt) || ~isfield(opt, 'show') || ~isfield(opt.show, 'isR') || opt.show.isR;
        figurePara.data.isMse = ~isempty(opt) && isfield(opt, 'show') && isfield(opt.show, 'isMse') && opt.show.isMse;
        figurePara.preserve.fold = ['savedFigure\' data.dataName '\' getOutputName(opt) '\' algoMode '\' tuneMode];
        for i = 1 : size(predictedTrain, 1)
            figurePara.label.title = [algoMode ' Regression of TrainingSet with Cross-' num2str(i)];
            figurePara.preserve.name = figurePara.label.title;
            if size(predictedTrain, 1) == 1
                figurePara.label.x = [figurePara.label.experimental, ' ' figurePara.label.yGene];
                figurePara.label.y = [figurePara.label.predicted, ' ' figurePara.label.yGene];
            else
                figurePara.label.x = [figurePara.label.experimental, ' ' figurePara.label.yGene{i}];
                figurePara.label.y = [figurePara.label.predicted, ' ' figurePara.label.yGene{i}];
            end
            drawRegression(data.trainYAllColumn(i,:), predictedTrain(i,:), figurePara);
        end
        
        % regression figure of test set
        figurePara = setFigurePara(data.dataName, data.posOutput);
        figurePara.data.isR = isempty(opt) || ~isfield(opt, 'show') || ~isfield(opt.show, 'isR') || opt.show.isR;
        figurePara.data.isMse = ~isempty(opt) && isfield(opt, 'show') && isfield(opt.show, 'isMse') && opt.show.isMse;
        figurePara.preserve.fold = ['savedFigure\' data.dataName '\' getOutputName(opt) '\' algoMode '\' tuneMode];
        for i = 1 : size(predictedTest, 1)
            figurePara.label.title = [algoMode ' Regression of TestSet with Cross-' num2str(i)];
            figurePara.preserve.name = figurePara.label.title;
            if size(predictedTrain, 1) == 1
                figurePara.label.x = [figurePara.label.experimental, ' ' figurePara.label.yGene];
                figurePara.label.y = [figurePara.label.predicted, ' ' figurePara.label.yGene];
            else
                figurePara.label.x = [figurePara.label.experimental, ' ' figurePara.label.yGene{i}];
                figurePara.label.y = [figurePara.label.predicted, ' ' figurePara.label.yGene{i}];
            end
            drawRegression(data.testYAllColumn(i,:), predictedTest(i,:), figurePara);
        end
        
        % regression figure of training set and test set
        figurePara = setFigurePara(data.dataName, data.posOutput);
        figurePara.data.isR = isempty(opt) || ~isfield(opt, 'show') || ~isfield(opt.show, 'isR') || opt.show.isR;
        figurePara.data.isMse = ~isempty(opt) && isfield(opt, 'show') && isfield(opt.show, 'isMse') && opt.show.isMse;
        figurePara.preserve.fold = ['savedFigure\' data.dataName '\' getOutputName(opt) '\' algoMode '\' tuneMode];
        for i = 1 : size(predictedTest, 1)
            figurePara.label.title = [algoMode ' Regression of TrainingSet and TestSet with Cross-' num2str(i)];
            figurePara.preserve.name = figurePara.label.title;
            if size(predictedTrain, 1) == 1
                figurePara.label.x = [figurePara.label.experimental, ' ' figurePara.label.yGene];
                figurePara.label.y = [figurePara.label.predicted, ' ' figurePara.label.yGene];
            else
                figurePara.label.x = [figurePara.label.experimental, ' ' figurePara.label.yGene{i}];
                figurePara.label.y = [figurePara.label.predicted, ' ' figurePara.label.yGene{i}];
            end
            drawRegression2(data.trainYAllColumn(i,:), predictedTrain(i,:), ...
                data.testYAllColumn(i,:), predictedTest(i,:), figurePara);
        end
    end