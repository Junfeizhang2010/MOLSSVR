function analysisBox(data, gap, algoMode, tuneMode, opt)
    gap(:, all(gap == 0, 1)) = [];
    gap(:, all(gap == inf, 1)) = [];
    gap(:, all(gap == -inf, 1)) = [];
    figurePara = setFigurePara(data.dataName, data.posOutput);
    figurePara.label.title = 'Difference of Predicted and measured Values of Each Model';
    figurePara.preserve.fold = ['savedFigure\', data.dataName '\' getOutputName(opt) '\' tuneMode];
    if contains(tuneMode, 'PSO'), figurePara.preserve.fold = ['savedFigure\', data.dataName '\' getOutputName(opt) '\PSO']; end
    figurePara.preserve.name = figurePara.label.title;
    figurePara.label.y = {'Residuals'};
    figurePara.label.x = algoMode;
    drawBox(gap, figurePara);