function preserveFigure(fold, name)
    path = getFold(mfilename('fullpath'), 2);
    folderPath = [path, fold];
    if ~exist(folderPath, 'file')
        mkdir(folderPath);
    end
    saveas(gcf,[path, fold, '\' name, '.tiff'], 'tiffn');
    saveas(gcf,[path, fold, '\' name, '.fig'], 'fig');