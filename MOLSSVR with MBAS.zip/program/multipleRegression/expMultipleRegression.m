function expMultipleRegression(opt)
    %% load data
    data = loadData(opt);

    %% Multioutput algorithm with optimization algorithm
    opt1 = opt;
    opt1.data.algoMode = opt.data.algoMode{1};
    opt1.data.data = data;
    opt1.isAnalysis.sensitivity = false;
    opt1.isAnalysis.partialDependency = false;
    opt1.isAnalysis.withoutTune = false;
    BASRs = expRegression(opt1);
    for i = 1 : length(BASRs.MSE{1})
        result{i}(1,1) = BASRs.MSE{1}{i};
        result{i}(1,2) = BASRs.RMSE{1}{i};
        result{i}(1,3) = BASRs.R{1}{i};
        result{i}(1,4) = BASRs.R2{1}{i};
        result{i}(1,5) = BASRs.MAPE{1}{i};
        result{i}(1,6) = BASRs.MAE{1}{i};
        result{i}(1,7) = median(BASRs.gap{1}{i});
        result{i}(1,8) = BASRs.Std{1}{i};
        result{i}(1,9) = BASRs.spandSecond;
    end
    
    %% Multi-output algorithm
    disp(['���� Data set: ' opt.data.dataName ' ����    MOLSSVR']);   fprintf('start at ');    beginTime = printNow();
    MultiRs = getErrorNormalMultiple(data, [], [], opt.data.algoMode{1}{1}, 'test', 1);
    fprintf('end at ');    endTime = printNow();
    for i = 1 : length(MultiRs.MSE)
        result{i}(2,1) = MultiRs.MSE{i};
        result{i}(2,2) = MultiRs.RMSE{i};
        result{i}(2,3) = MultiRs.R{i};
        result{i}(2,4) = MultiRs.R2{i};
        result{i}(2,5) = MultiRs.MAPE{i};
        result{i}(2,6) = MultiRs.MAE{i};
        result{i}(2,7) = median(MultiRs.gap{i});
        result{i}(2,8) = MultiRs.Std{i};
        result{i}(2,9) = etime(endTime, beginTime);
    end

    %% Single-output algorithm
    disp(['���� Data set: ' opt.data.dataName ' ����    Others']);   fprintf('start at ');    beginTime = printNow();
    for j = 1 : length(opt.data.algoMode{2})
        for i = 1 : length(opt.data.posOutput)
            dataTemp = data;
            dataTemp.trainYAllRow = dataTemp.trainYAllRow(:,i);
            dataTemp.testYAllRow = dataTemp.testYAllRow(:,i);
            singleRs = getErrorNormal2(dataTemp, [], [], opt.data.algoMode{2}{j}, 'test');
            result{i}(2+j, 1) = singleRs.MSE;
            result{i}(2+j, 2) = singleRs.RMSE;
            result{i}(2+j, 3) = singleRs.R;
            result{i}(2+j, 4) = singleRs.R2;
            result{i}(2+j, 5) = singleRs.MAPE;
            result{i}(2+j, 6) = singleRs.MAE;
            result{i}(2+j, 7) = median(singleRs.gap);
            result{i}(2+j, 8) = singleRs.Std;
        end
        for i = 1 : length(opt.data.posOutput)
            result{i}(2+j, 9) = etime(endTime, beginTime);  
        end
    end
    fprintf('end at ');    endTime = printNow();
    
    %% save
    savePath = [getFold(mfilename('fullpath'), 2), 'savedData\' opt.data.dataName '\Multiple\contrast the conclusion'];
    outputName = getYGene(opt);
    for j = 1 : length(result)
        table{j}.columnItem = {'MSE', 'RMSE', 'R', 'R2', 'MAE', 'MAPE', 'difference median', 'SD', 'time cost'};
        algoMode{1,1} = [opt1.data.tuneMode '+' opt.data.algoMode{1}{1}];
        algoMode{2,1} = opt.data.algoMode{1}{1};
        for i = 1 : length(opt.data.algoMode{2})
            algoMode{i + 2,1} = [opt.data.algoMode{2}{i} 's'];
        end
        table{j}.rowItem = algoMode;
        table{j}.result = result{j};

        save(savePath, 'data', 'table');
        saveExcel(result{j}, table{j}.columnItem, table{j}.rowItem, savePath, outputName{j});
    end