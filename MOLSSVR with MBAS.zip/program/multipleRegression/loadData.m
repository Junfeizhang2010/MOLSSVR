function data = loadData(opt)
    disp('��prepare data...');
    % load data
    if isfield(opt, 'data')
        data = opt.data;
    end
    if isfield(opt, 'all')
        data.all = opt.all;
    end
    if ~isfield(opt, 'data') || ~isfield(opt.data, 'isTranspose')
        data.isTranspose = false; 
    else
        data.isTranspose = opt.data.isTranspose;
    end
    data = loadIn(data);
    
    % eigenvalues and target values
    if ~isfield(opt, 'data') || ~isfield(opt.data, 'posOutput')
        data.posOutput = 1;
    else
        data.posOutput = opt.data.posOutput;
    end
    if ~isfield(opt, 'data') || ~isfield(opt.data, 'posLastInput')
        data.posLastInput = data.posOutput + 1;
    else
        data.posLastInput = opt.data.posLastInput;
    end
    data = getFeatureAndTarget(data);
    
    % normalization
    if ~isfield(opt, 'data') || ~isfield(opt.data, 'isNormY')
        data.isNormY = false;
    else
        data.isNormY = opt.data.isNormY;
    end
    data = dataNormalize(data);

    % Training set and test set
    if ~isfield(opt, 'data') || ~isfield(opt.data, 'trainPer')
        data.trainPer = 0.7; 
    else
        data.trainPer = opt.data.trainPer;
    end
    data = getTrainAndTest(data);
    
    % n fold cross validation
    if ~isfield(opt, 'data') || ~isfield(opt.data, 'crossCount')
        data.crossCount = 10; 
    else
        data.crossCount = opt.data.crossCount;
    end
    data = getCross(data, 'train');