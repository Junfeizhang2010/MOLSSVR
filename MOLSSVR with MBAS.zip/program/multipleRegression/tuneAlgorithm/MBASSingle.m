function [xfStore, fBestStore, modelBest, etas, xBest, figLineBestStore] = BASSingle(data, algoMode, x, crossIndex, opt, others)
    step  = opt.step;
    c     = opt.c;
    n     = opt.n;
    eta   = opt.eta;
    if isfield(opt, 'eta') && strcmp(opt.eta, 'self-adaption')
        alpha = opt.alpha; % The weight of the two adding terms
    end
    if isempty(others) || ~isfield(others, 'print') || ~isfield(others.print, 'gap'),    others.print.gap = 10;   end
    
    xBest = x;                 % best position
    [fBestStore, modelBest, figLineBestStore] = getError(data, crossIndex, algoMode, xBest, others);     % The objective function value of the best position

    fBest  = fBestStore;
    fWorst = fBestStore;
    xfStore = [0; x; fBest];    % Stores the best position of each iteration
    figLineBest = figLineBestStore;

    for i = 1 : n
        if isempty(others) || ~isfield(others, 'print') || ~isfield(others.print, 'is')  || others.print.is
            if i ~= n
                if rem(i, others.print.gap) == 0
                    fprintf(['iterations ' num2str(i) '/' num2str(n) ', ']);
                end
            else           
                disp(['iterations ' num2str(i) '/' num2str(n)]);
            end
        end

        d0     = step / c;                   % Length of beard
        dir    = rands(size(x, 1), 1);
        dir    = dir / (eps + norm(dir));
        xLeft  = limit(x + dir * d0, algoMode);                             % left position 
        fLeft  = getError(data, crossIndex, algoMode, xLeft, others);       % The objective function value of left position 
        xRight = limit(x - dir * d0, algoMode);                             % right position 
        fRight = getError(data, crossIndex, algoMode, xRight, others);      % The objective function value of right position
        rnd    = ceil(rand * length(fLeft));
        x      = limit(x - step * dir * sign(fLeft(rnd) - fRight(rnd)), algoMode);    % get new position
        [f, model, figLine] = getError(data, crossIndex, algoMode, x, others);        % The objective function value of new position
        
        % If the target function value at the new position is better
        if mean(f < fBest) > 0.5
            xBest = x;              % update xbest
            fBest = f;              % update fbest
            modelBest = model;
        end
        if mean(f > fWorst) > 0.5
            fWorst = f;             % update fWorst
        end
        if figLine < figLineBest
            figLineBest = figLine;
        end
        xfStore    = cat(2, xfStore, [i;x;f]);
        fBestStore = cat(2, fBestStore, fBest);                 % The value of the objective function for each iteration
        figLineBestStore = [figLineBestStore, figLineBest];     % Error line 
        
        % Constant proportional decay step size (BAS)
        if isfield(opt, 'eta') && isnumeric(opt.eta)
            etas(i) = eta;   % Step length coefficient
            
        % Self-adaptive step size
        else
            switch eta
                case 'self-adaption'
                    if fWorst ~= fBest
                        etas(i) = 1;
                    else
                        etas(i) = (1 - alpha) * eta + alpha * (fWorst(rnd) - f(rnd)) / (fWorst(rnd) - fBest(rnd));
                    end
            end
        end
        % Use Levy's random number when the convergence is slow
        if isfield(opt, 'isLevy') && opt.isLevy
            if fWorst(rnd) ~= fBest(rnd) && abs(f - xfStore(end, i)) < (fWorst(rnd) - fBest(rnd)) * 0.00001
                etas(i) = abs(LevyFlights(1) * 10) + 1;
            end
        end
        step = step * etas(i);
    end