function [xfStoreBest, fBestStoreBest, modelBestStroreBest, foldBest, xBest, fBest, bestIteration, figLineBestStoreBest] = MBAS(data, algoMode, xInit, opt, others)
    
    tuneMode = 'BAS';
    if ~isempty(opt) && isfield(opt, 'task'),   others.task = opt.task;   end
    for j = 1 : opt.time
        fprintf(['                  fold ' num2str(j) '/' num2str(opt.time) ': ']);
        [xfStore{j}, fBestStore{j}, modelBest{j}, ~, ~, figLineBestStore{j}] = MBASSingle(data, algoMode, xInit, j, opt.BAS, others);
    end
    
    % Take the set of values containing the best results from the ten-fold cross validation as the output of this function
    for j = 1 : opt.time
        fBestAll(j) = min(fBestStore{j});
        figLine(j) = min(figLineBestStore{j});
    end
    [~, foldBest] = min(fBestAll);
    xfStoreBest = xfStore{foldBest};
    fBestStoreBest = fBestStore{foldBest}';
    modelBestStroreBest = modelBest{foldBest};
    [fBest, bestIteration] = min(xfStoreBest(end,:));
    xBest = xfStoreBest(2:end-1, bestIteration);
    figLineBestStoreBest = figLineBestStore{foldBest};

    %% draw
    if ~isfield(opt, 'show') || ~isfield(opt.show, 'isDraw') || opt.show.isDraw
        % Error histogram
        figurePara = setFigurePara(data.dataName, data.posOutput);
        figurePara.label.x = 'Fold number';
        figurePara.label.title = ['Histogram of  ' algoMode ' error in 10-fold cross validation with ' tuneMode ' tuning'];
        figurePara.preserve.name = figurePara.label.title;
        figurePara.preserve.fold = ['savedFigure\' data.dataName '\' getOutputName(opt) '\' algoMode '\' tuneMode];
        if isfield(opt, 'show') && isfield(opt.show, 'isMSE') && opt.show.isMSE
            figurePara.label.y = figurePara.label.mse;
            drawData = fBestAll;
        else
            figurePara.label.y = figurePara.label.rmse;
            drawData = sqrt(fBestAll);
        end
        drawHistogram(drawData, figurePara);
    end