function [evaRsTest, spandSecond, bestIterationMSE, bestIterationRMSE] = analysisAlgorithm(data, tuneMode, algoMode, opt)

    %% Optimize
    begin = clock;
    model = [];
    bestIterationMSE = [];
    [para, bestIterationMSE, model, bestFold] = tune(data, tuneMode, algoMode, opt);
    bestIterationRMSE = sqrt(bestIterationMSE);
    spandSecond = etime(clock, begin);
    diary on;    fprintf([', time cost: ' num2str(spandSecond)]);   disp(' second');    diary off;
    mkdir(getFold(mfilename('fullpath'), 2), ['savedData\' data.dataName '\' getOutputName(opt)]);
    
    %% evaluate
    evaRsTest = evaluate2(data, model, tuneMode, algoMode, para, bestFold, opt);

    savePath = [getFold(mfilename('fullpath'), 2), 'savedData\' data.dataName '\' getOutputName(opt) '\' tuneMode];
    save([savePath '\data of ', tuneMode, ' - ', algoMode], 'para', 'evaRsTest', 'spandSecond', 'model');