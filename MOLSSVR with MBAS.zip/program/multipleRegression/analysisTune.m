function analysisTune(data, bestIterationMSEOrRMSE, algoMode, tuneMode, opt)
    n = length(bestIterationMSEOrRMSE);
    len = size(bestIterationMSEOrRMSE{1}, 1);
    for i = 2 : n
        if size(bestIterationMSEOrRMSE{1}, 1) < len
            len = size(bestIterationMSEOrRMSE{1}, 1);
        end
    end
    for i = 1 : n
        iterData{i} = bestIterationMSEOrRMSE{i}(1:len, :)';
    end

    figurePara = setFigurePara(data.dataName, data.posOutput);
    figurePara.label.title = 'Iterative Convergence of Parameters Tuning with BAS of Each Model';
    figurePara.preserve.fold = ['savedFigure\', data.dataName '\' getOutputName(opt) '\' tuneMode];
    figurePara.preserve.name = figurePara.label.title;
    figurePara.label.x = 'Iteration';
    figurePara.label.legend = algoMode;
    if isfield(opt, 'show') && isfield(opt.show, 'isMSE') && opt.show.isMSE
        figurePara.label.y = figurePara.label.mse;
    else
        figurePara.label.y = figurePara.label.rmse;
    end
    drawMultipleLine([],iterData, figurePara);