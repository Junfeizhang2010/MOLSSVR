%   ==============================================   % 
%                                                    %
%   JunFei Zhang, junfeizhang2010@163.com, 2019,     %
%                                                    %
%   ==============================================   %    


clear;close all;warning off;
opt.data.dataName = 'SA';
opt.data.posLastInput = 3;
opt.data.posOutput = 1:2;
opt.data.algoMode{1} = {'MLSSVR'};
opt.data.algoMode{2} = {'SVM', 'LR', 'MLR'};
opt.data.tuneMode = 'MBAS';
opt.MLSSVR.BAS.eta = 'self-adaption';
opt.MLSSVR.BAS.n = 10;
expMultipleRegression(opt)